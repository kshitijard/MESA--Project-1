var searchData=
[
  ['adjust_5fbrightness_0',['adjust_brightness',['../main_8cpp.html#a060e673278fff9d83a5ca3437754170b',1,'main.cpp']]]
];
