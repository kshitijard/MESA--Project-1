var searchData=
[
  ['read_5ftemp_0',['read_temp',['../_d_s1631_8cpp.html#a68bddee4558036eb6ad88d97667184bb',1,'DS1631.cpp']]]
];
