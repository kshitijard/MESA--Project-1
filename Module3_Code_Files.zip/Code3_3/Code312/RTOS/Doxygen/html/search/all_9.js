var searchData=
[
  ['pc_5fterminal_0',['pc_terminal',['../main_8cpp.html#a465b2317afe9725c53a3c0774ed2e1fd',1,'main.cpp']]],
  ['pot_1',['Pot',['../main_8cpp.html#a561ad4761bdf0998d3283c2047836f19',1,'main.cpp']]]
];
