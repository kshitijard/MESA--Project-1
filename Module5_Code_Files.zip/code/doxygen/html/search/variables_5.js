var searchData=
[
  ['read_5ftemp_0',['read_temp',['../_d_s1631_8cpp.html#a68bddee4558036eb6ad88d97667184bb',1,'DS1631.cpp']]],
  ['rx_5fbuf_1',['rx_buf',['../shared_8h.html#aa969d20975922ea763530e4e9d4b851b',1,'shared.h']]],
  ['rx_5fin_5fptr_2',['rx_in_ptr',['../shared_8h.html#ab12a4058a0d03f4d5015439873548f1e',1,'shared.h']]],
  ['rx_5fout_5fptr_3',['rx_out_ptr',['../shared_8h.html#a2ae6b659fbdaaf56342c00b70e127172',1,'shared.h']]]
];
