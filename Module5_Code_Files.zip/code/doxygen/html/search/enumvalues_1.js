var searchData=
[
  ['false_0',['FALSE',['../shared_8h.html#a7c6368b321bd9acd0149b030bb8275edaa1e095cc966dbecf6a0d8aad75348d1a',1,'shared.h']]]
];
