var searchData=
[
  ['stack_0',['STACK',['../shared_8h.html#ad8667bac763ba2aa5d7c29541fecf0a6a3bfeb3e4822bcc96abf42601a42bbcd3',1,'shared.h']]]
];
