var searchData=
[
  ['register_0',['REGISTER',['../shared_8h.html#ad8667bac763ba2aa5d7c29541fecf0a6aceb7c305772dab23a260960771180df3',1,'shared.h']]]
];
