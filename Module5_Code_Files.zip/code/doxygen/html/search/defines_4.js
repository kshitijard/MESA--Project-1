var searchData=
[
  ['main_0',['MAIN',['../main_8cpp.html#a34b04bd23b07b485921a728ad0805ac4',1,'main.cpp']]],
  ['msg_5fbuf_5fsize_1',['MSG_BUF_SIZE',['../shared_8h.html#a8b8af8bedcac87c0d3c68634448b94a7',1,'shared.h']]]
];
