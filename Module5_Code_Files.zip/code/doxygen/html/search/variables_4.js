var searchData=
[
  ['msg_5fbuf_0',['msg_buf',['../shared_8h.html#aba8f2c25e1b131518be3427ec7ff9898',1,'shared.h']]],
  ['msg_5fbuf_5fidx_1',['msg_buf_idx',['../shared_8h.html#ab429473c00b4c6b483dec76f22256f25',1,'shared.h']]]
];
