var searchData=
[
  ['version_0',['VERSION',['../shared_8h.html#ad8667bac763ba2aa5d7c29541fecf0a6a52f49aba124a600ad9581caabe6a099a',1,'shared.h']]]
];
