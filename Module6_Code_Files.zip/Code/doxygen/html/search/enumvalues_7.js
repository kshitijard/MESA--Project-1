var searchData=
[
  ['true_0',['TRUE',['../shared_8h.html#a7c6368b321bd9acd0149b030bb8275edaa82764c3079aea4e60c80e45befbb839',1,'shared.h']]]
];
