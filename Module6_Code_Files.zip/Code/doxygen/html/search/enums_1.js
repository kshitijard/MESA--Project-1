var searchData=
[
  ['dmode_0',['dmode',['../shared_8h.html#ad8667bac763ba2aa5d7c29541fecf0a6',1,'shared.h']]]
];
