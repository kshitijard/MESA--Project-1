var searchData=
[
  ['lcd_5fclk_5fpin_0',['LCD_CLK_PIN',['../main_8cpp.html#ad82d29d2cc3583bb5b798d6bad5fabc9',1,'main.cpp']]],
  ['lcd_5fcs_5fpin_1',['LCD_CS_PIN',['../main_8cpp.html#a50d72083b1ed4dd0bc2eaabb4a0332c8',1,'main.cpp']]],
  ['lcd_5fmosi_5fpin_2',['LCD_MOSI_PIN',['../main_8cpp.html#a6e017a8fc269f29da6204f360385a65b',1,'main.cpp']]],
  ['led_5fflash_5fperiod_3',['LED_FLASH_PERIOD',['../shared_8h.html#acf08b26e9b85646a7f06ec2d27899084',1,'shared.h']]]
];
