var searchData=
[
  ['normal_0',['NORMAL',['../shared_8h.html#ad8667bac763ba2aa5d7c29541fecf0a6a50d1448013c6f17125caee18aa418af7',1,'shared.h']]]
];
