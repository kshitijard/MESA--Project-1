var searchData=
[
  ['debug_0',['DEBUG',['../shared_8h.html#ad8667bac763ba2aa5d7c29541fecf0a6a0593585da9181e972974c1274d8f2b4f',1,'shared.h']]]
];
