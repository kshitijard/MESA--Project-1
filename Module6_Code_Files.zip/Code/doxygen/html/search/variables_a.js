var searchData=
[
  ['vortex_5ffreq_0',['vortex_freq',['../main_8cpp.html#ac8829a0de027f37603dc9b5cb15643c8',1,'vortex_freq():&#160;main.cpp'],['../_monitor_8cpp.html#ac8829a0de027f37603dc9b5cb15643c8',1,'vortex_freq():&#160;main.cpp']]]
];
