var searchData=
[
  ['serial_0',['serial',['../shared_8h.html#a44becc30285e88213a624428b2b46cdf',1,'serial(void):&#160;UART_poll.cpp'],['../_u_a_r_t__poll_8cpp.html#a44becc30285e88213a624428b2b46cdf',1,'serial(void):&#160;UART_poll.cpp']]],
  ['set_5fdisplay_5fmode_1',['set_display_mode',['../_monitor_8cpp.html#acd5157b5f415f4ca9be9b2a23943440c',1,'set_display_mode(void):&#160;Monitor.cpp'],['../shared_8h.html#acd5157b5f415f4ca9be9b2a23943440c',1,'set_display_mode(void):&#160;Monitor.cpp']]],
  ['status_5freport_2',['status_report',['../shared_8h.html#ad6e5f59640709c2b2e22f5df6b1b5a65',1,'shared.h']]]
];
