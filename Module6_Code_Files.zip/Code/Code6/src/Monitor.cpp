/**----------------------------------------------------------------------------
             \file Monitor.cpp
--                                                                           --
--            ECEN 5803 Mastering Embedded System Architecture               --
--                          Project 1 Module 6                               --
--                       Microcontroller Firmware                            --
--                             Monitor.cpp                                   --
--                                                                           --
-------------------------------------------------------------------------------
--
--  Designed for:  University of Colorado at Boulder
--
--
--  Designed by:  Tim Scherr
--  Revised by:  Kshitija Dhondage, Ajay Kandagal
--
-- Version: 2.0
-- Date of current revision:  2023-10-21
-- Target Microcontroller: ST STM32F401RE
-- Tools used:  ARM mbed compiler
--              ARM mbed SDK
--              ST Nucleo STM32F401RE Board
--
--
   Functional Description: See below
--
--      Copyright (c) 2015, 2022 Tim Scherr All rights reserved.
--
*/
#include <stdio.h>
#include "shared.h"

extern float temp_val, flow_rate;
extern uint16_t vortex_freq;

/*******************************************************************************
 * Set Display Mode Function
 * Function determines the correct display mode.  The 3 display modes operate as
 *   follows:
 *
 *  NORMAL MODE       Outputs only mode and state information changes
 *                     and calculated outputs
 *
 *  QUIET MODE        No Outputs
 *
 *  DEBUG MODE        Outputs mode and state information, error counts,
 *                    register displays, sensor states, and calculated output
 *                  (currently not all features are operation, could be enhanced)
 *
 * There is deliberate delay in switching between modes to allow the RS-232 cable
 * to be plugged into the header without causing problems.
 *******************************************************************************/

void set_display_mode(void)
{
   UART_direct_msg_put("\r\n *********** Select Mode ***********");
   UART_direct_msg_put("\r\n 1] Hit NOR - Normal");
   UART_direct_msg_put("\r\n 2] Hit QUI - Quiet");
   UART_direct_msg_put("\r\n 3] Hit DEB - Debug");
   UART_direct_msg_put("\r\n 4] Hit REG - Register: RO-R15");
   UART_direct_msg_put("\r\n 5] Hit MEM - Memory: Data Section");
   UART_direct_msg_put("\r\n 6] Hit STA - Stack: 16 words");
   UART_direct_msg_put("\r\n 7] Hit V   - Version#\r\n");
   UART_direct_msg_put("\r\n ***********************************");
   UART_direct_msg_put("\r\n Enter Mode:  ");
}

__asm uint32_t address_ret(int x)
{
   MOVS R3, R0 // Copy the value of R0 that is address X to R3
   LDR R0, [R3]  // Load the value at the address pointed to by R3 into R0
   BX LR // Return to the calling function
}

//*****************************************************************************/
/// \fn void chk_UART_msg(void)
///
///  \brief - fills a message buffer until return is encountered, then calls
///           message processing
//*****************************************************************************/
/****************      ECEN 5803 add code as indicated   **********************/
// Improve behavior of this function
void chk_UART_msg(void)
{
   uchar8_t j;
   while (UART_input()) // becomes true only when a byte has been received
   {                    // skip if no characters pending
      j = UART_get();   // get next character

      if (j == '\r') // on a enter (return) key press
      {              // complete message (all messages end in carriage return)
         UART_msg_put("->");
         UART_msg_process();
      }
      else
      {
         if ((j != 0x02)) // if not ^B
         {                // if not command, then
            UART_put(j);  // echo the character
         }
         else
         {
            ;
         }
         if (j == '\b')
         { // backspace editor
					 // EDIT: check greater than instead of == comparison. This will make sure value never goes below 0.
            if (msg_buf_idx > 0)
            {                       // if not 1st character then destructive
               UART_msg_put(" \b"); // backspace
               msg_buf_idx--;
            }
         }
         else if (msg_buf_idx >= MSG_BUF_SIZE)
         { // check message length too large
            UART_msg_put("\r\nToo Long!");
            msg_buf_idx = 0;
         }
				 // EDIT: Added additional checks for new commands added
         else if ((display_mode == QUIET) && (msg_buf[0] != 0x02) &&
                  (msg_buf[0] != 'D') && (msg_buf[0] != 'N') &&
                  (msg_buf[0] != 'V') && (msg_buf[0] != 'M') &&
				      (msg_buf[0] != 'R') && (msg_buf[0] != 'S') &&
                  (msg_buf_idx != 0))
         {                   // if first character is bad in Quiet mode
            msg_buf_idx = 0; // then start over
         }
         else
         { // not complete message, store character

            msg_buf[msg_buf_idx] = j;
            msg_buf_idx++;
            if (msg_buf_idx > 2)
            {
               UART_msg_process();
            }
         }
      }
   }
}

//*****************************************************************************/
///  \fn void UART_msg_process(void)
/// UART Input Message Processing
//*****************************************************************************/
void UART_msg_process(void)
{
   uchar8_t chr, err = 0;
   //   unsigned char  data;

   if ((chr = msg_buf[0]) <= 0x60)
   { // Upper Case
      switch (chr)
      {
      case 'D':
         if ((msg_buf[1] == 'E') && (msg_buf[2] == 'B') && (msg_buf_idx == 3))
         {
            display_mode = DEBUG;
            UART_msg_put("\r\nMode=DEBUG\n");
            display_timer = 0;
         }
         else
            err = 1;
         break;

      case 'N':
         if ((msg_buf[1] == 'O') && (msg_buf[2] == 'R') && (msg_buf_idx == 3))
         {
            display_mode = NORMAL;
            UART_msg_put("\r\nMode=NORMAL\n");
            // display_timer = 0;
         }
         else
            err = 1;
         break;

      case 'Q':
         if ((msg_buf[1] == 'U') && (msg_buf[2] == 'I') && (msg_buf_idx == 3))
         {
            display_mode = QUIET;
            UART_msg_put("\r\nMode=QUIET\n");
            display_timer = 0;
         }
         else
            err = 1;
         break;
      /****************      ECEN 5803 add code as indicated   **********************/
      //  Add other message types here
      case 'M':
         if ((msg_buf[1] == 'E') && (msg_buf[2] == 'M') && (msg_buf_idx == 3))
         {
            display_mode = MEMORY;
            UART_msg_put("\r\nMode=MEMROY\n");
            // display_timer = 0;
         }
         else
            err = 1;
         break;

      case 'S':
         if ((msg_buf[1] == 'T') && (msg_buf[2] == 'A') && (msg_buf_idx == 3))
         {
            display_mode = STACK;
            UART_msg_put("\r\nMode=STACK\n");
            // display_timer = 0;
         }
         else
            err = 1;
         break;

      case 'R':
         if ((msg_buf[1] == 'E') && (msg_buf[2] == 'G') && (msg_buf_idx == 3))
         {
            display_mode = REGISTER;
            UART_msg_put("\r\nMode=REGISTER\n");
            // display_timer = 0;
         }
         else
            err = 1;
         break;

      case 'V':
         if (msg_buf_idx == 1)
         {
            display_mode = VERSION;
            UART_msg_put("\r\n");
            UART_msg_put(CODE_VERSION);
            UART_msg_put("\r\n Enter mode  ");
            display_timer = 0;
}
			else
				err = 1;
         break;

      default:
         err = 1;
      }
   }

   else
   { // Lower Case
      switch (chr)
      {
      default:
         err = 1;
      }
   }

   if (err == 1)
   {
      UART_msg_put("\n\rEntry Error!");
   }
   else if (err == 2)
   {
      UART_msg_put("\n\rNot in DEBUG Mode!");
   }
   else
   {
      msg_buf_idx = 0; // put index to start of buffer for next message
      ;
   }
   msg_buf_idx = 0; // put index to start of buffer for next message
}

//*****************************************************************************
///   \fn   is_hex
/// Function takes
///  @param a single ASCII character and returns
///  @return 1 if hex digit, 0 otherwise.
///
//*****************************************************************************
uchar8_t is_hex(uchar8_t c)
{
   if ((((c |= 0x20) >= '0') && (c <= '9')) || ((c >= 'a') && (c <= 'f')))
      return 1;
   return 0;
}

__asm void mov_regs(uint32_t *all_reg)
{
	STM r0, {r0-r12}
	BX lr
}

/*******************************************************************************
 *   \fn  DEBUG and DIAGNOSTIC Mode UART Operation
 *******************************************************************************/
void monitor(void)
{

   /**********************************/
   /*     Spew outputs               */
   /**********************************/

   switch (display_mode)
   {
   case (QUIET):
   {
      // UART_msg_put("\r\n ");
      display_flag = 0;
   }
   break;
   case (VERSION):
   {
      display_flag = 0;
   }
   break;
   case (NORMAL):
   {
      if (display_flag == 1)
      {
         UART_msg_put("\r\nNORMAL ");
         printf(" Flow: ");
         // ECEN 5803 add code as indicated
         //  add flow data output here, use UART_hex_put or similar for numbers
         printf("%0.2f", flow_rate);
				
         printf(" Temp: ");
         //  add flow data output here, use UART_hex_put or similar for numbers
         printf("%0.2f C", temp_val);
				
         printf(" Freq: ");
         //  add flow data output here, use UART_hex_put or similar for numbers
         printf("%d Hz", vortex_freq);
				
         display_flag = 0;
      }
   }
   break;
   case (DEBUG):
   {
      if (display_flag == 1)
      {
         UART_msg_put("\r\nDEBUG ");
         printf(" Flow: ");
         // ECEN 5803 add code as indicated
         //  add flow data output here, use UART_hex_put or similar for
         // numbers
         printf("%0.2f", flow_rate);
				
         printf(" Temp: ");
         //  add flow data output here, use UART_hex_put or similar for
         // numbers
         printf("%0.2f C", temp_val);
				
         printf(" Freq: ");
         //  add flow data output here, use UART_hex_put or similar for
         // numbers
         printf("%d Hz", vortex_freq);

         // clear flag to ISR
         display_flag = 0;
      }
   }
   break;
	 /****************      ECEN 5803 add code as indicated   **********************/
	 //  Create a display of  error counts, sensor states, and
	 //  ARM Registers R0-R15

	 //  Create a command to read a section of Memory and display it

	 //  Create a command to read 16 words from the current stack
	 // and display it in reverse chronological order.
   case (MEMORY):
   {
      if (display_flag == 1)
      {
         uint32_t mem_buff[32];
         int start_addr = 536870912;
         UART_direct_msg_put("\n\r Data Memory dump from 0x20000000 to 0x2000007F\r\n");

         for (uint8_t i = 0; i < 32; i++)
         {
            mem_buff[i] = address_ret(start_addr);

            printf("%02X %02X %02X %02X ", (mem_buff[i] & 0xFF),
                   (mem_buff[i] >> 8) & 0xFF,
                   (mem_buff[i] >> 16) & 0xFF,
                   (mem_buff[i] >> 24) & 0xFF);

            start_addr += 4; // Move to the next 4-byte memory address.

            if (i % 2 != 0)
            {
               UART_direct_msg_put("\n\r");
            }
         }

         display_flag = 0;
      }
   }
   break;

   case (STACK):
   {
      if (display_flag == 1)
      {
         UART_direct_msg_put("\n\r Stack Dump: 16 words \r\n");

				 register uint32_t stack_val __asm ("sp");
         uint32_t *stack_addr = (uint32_t *)stack_val;

         for (int i = 0; i < 16; i++)
         {
            UART_direct_hex_put((*stack_addr & 0xFF000000) >> 24);
            UART_direct_hex_put((*stack_addr & 0x00FF0000) >> 16);
            UART_direct_hex_put((*stack_addr & 0x0000ff00) >> 8);
            UART_direct_hex_put(*stack_addr & 0x000000FF);
            UART_direct_msg_put("\n\r");

            stack_addr++;
         }

         UART_direct_msg_put("\n\r");
         display_flag = 0;
      }
   }
   break;

   case (REGISTER):
		 if (display_flag == 1)
		 {
			 uint32_t all_regs[16];
			 mov_regs(all_regs);
			 
			 UART_direct_msg_put("\n\r Register Dump: 16 words \r\n");
			 
			 for (int i = 0; i < 16; i++)
			 {
					UART_direct_put('R');
				  if ( i < 10) {
						UART_direct_put(i + '0');
					}
					else {
						UART_direct_put('1');
						UART_direct_put((i % 10) + '0');
					}
					UART_direct_msg_put("\t");
					UART_direct_hex_put((all_regs[i] & 0xFF000000) >> 24);
					UART_direct_hex_put((all_regs[i] & 0x00FF0000) >> 16);
					UART_direct_hex_put((all_regs[i] & 0x0000ff00) >> 8);
					UART_direct_hex_put(all_regs[i] & 0x000000FF);
					UART_direct_msg_put("\n\r");
			 }
			 
			 display_flag = 0;
   }
   break;

   default:
   {
      UART_msg_put("Mode Error");
   }
   }
}
