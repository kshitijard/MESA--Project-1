#include "stm32f4xx_hal_adc.h"

class VortexFlow {
	public:
		void init();
		float get_temp();
	  uint16_t get_vortex_freq();
		uint16_t get_vortex_period_us();
		float get_vol_flow(float freq, float temp);
	private:
		ADC_HandleTypeDef temp_hadc;
		ADC_HandleTypeDef vref_hadc;
		ADC_HandleTypeDef vortex_hadc;
};
